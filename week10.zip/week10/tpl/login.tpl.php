<html>
    <body>
      <form action="../public_html/login.php" method="POST">
      <label for="username">Enter Your Username</label>
      <input type="text" id="username" name="username" value="">

<br>
      <label for="password">Enter Your Password</label>
      <input type="text" id="password" name="password" value="">
    
<br>
      <button type="submit" name="submitLogin">Submit</button>
      <button type="reset">Reset</button>
    </form>
    </body>
</html>
