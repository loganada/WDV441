<?php
//load
function load($tableName, $keyField, $key){

return $dataArray;
}
//save
function save($loginAttempt){

  return $loginAttempt;
}
//validate
function validate($keyField, $key){

  return $dataArray;
}
 ?>
