<?php
class Phone{
protected var $processors;
protected var $color;
protected var $size;

function getProcessors(){
  //CODE
}

function getColor(){
  //CODE
}
function getSize(){
  //CODE
}
}
?>
