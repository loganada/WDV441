<?php
class User
{


  function load($tableName, $key, $keyField)
  {

  }
  function save()
  {

  }
  function validate($key, $keyField)
  {

  }
}

 ?>
