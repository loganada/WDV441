<?php
class User_specific extends User
{
  var $color;
  var $name;
  var $email;
  var $picture;
  var $bio;

  function changeInfo()
  {

  }
  function viewMessages()
  {

  }
  function sendMessage()
  {

  }
  function viewProfile()
  {
    
  }
}

 ?>
