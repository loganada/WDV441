<?php
class Vehicle
{
  var $doors;
  var $engine;
  var $make;
  var $model;
  var $wheels;
  var $color;

  function start()
  {

  }
  function stop()
  {

  }
  function moveForward()
  {

  }
  function moveBackwards()
  {

  }
  function changeTire()
  {

  }
  function changeColor($newColor)
  {

  }
}

 ?>
