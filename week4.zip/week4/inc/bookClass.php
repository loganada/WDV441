<?php
class Book
{
  var $numOfPages;
  var $cover;
  var $content;

  function read()
  {

  }
  function turnPage()
  {

  }
  function open()
  {
    
  }
  function close()
  {

  }
}

 ?>
