<?php
class BuisinessObjectBase
{
  function load($recordToLoad)
  {

  }
  function validate($dataArray)
  {

  }
  function save($dataArray)
  {
    
  }
}
?>
