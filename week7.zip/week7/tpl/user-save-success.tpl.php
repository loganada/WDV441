<html>
    <body>
        yay!<br>
        <a href="user-list.php">Back to User List</a>
    </body>
</html>
